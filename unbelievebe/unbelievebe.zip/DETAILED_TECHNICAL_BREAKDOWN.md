# Unbelievebe: Detailed Technical Breakdown

## 🎯 ARCHITECTURE OVERVIEW

### **Current MVP Architecture (What You Have Now)**

```
USER INTERFACE (Frontend)
    ↓
Chat Input Box
    ↓
Claude API Call (Backend)
    ↓
System Prompt (Instructions to Claude)
    ↓
Claude Response
    ↓
Display in Chat
```

**Current Flow:**
1. User types question
2. Sends to backend API
3. Backend calls Claude API
4. Claude generates answer (based on system prompt)
5. Answer appears in chat
6. Very simple, very fast

---

## 📝 SYSTEM PROMPT - HOW CLAUDE BEHAVES

### **Current System Prompt (In route.js)**

```javascript
const SYSTEM_PROMPT = `You are Unbelievebe, a knowledgeable Malaysian landlord 
consultant app. You help landlords with practical, legally-sound 
advice about tenant management, rental agreements, and property 
maintenance in Malaysia.

IMPORTANT CONTEXT:
- Malaysia has different rental laws by state
- Always mention if laws differ by state
- Focus on common landlord questions: late rent, damages, 
  maintenance, deposits, eviction
- Provide practical, actionable advice
- Always include disclaimers that legal matters should be 
  reviewed by a qualified lawyer`
```

### **What This Does:**

When you ask Claude a question, this prompt tells Claude:
- ✅ "You are a Malaysian landlord expert"
- ✅ "Give practical advice"
- ✅ "Mention state differences"
- ✅ "Always add disclaimers"

### **What This DOESN'T Do:**

- ❌ Doesn't know about user's specific state
- ❌ Doesn't know about user's property type
- ❌ Doesn't give customized answers
- ❌ Doesn't handle multi-property scenarios

**Example Problem:**
```
User (from Johor): "How much notice for eviction?"
Claude: "You need to give proper notice and follow legal process"
(Generic - not Johor-specific!)

User (from Selangor): "How much notice?"
Same generic answer!
(Should be different!)
```

---

## 🔧 PROPOSED ENHANCED SYSTEM PROMPT

### **What We Would Change (But NOT YET)**

```javascript
const SYSTEM_PROMPT = `You are Unbelievebe, Malaysia's comprehensive 
property expert platform.

USER CONTEXT (You know this about them):
- State: [Retrieved from user profile]
- Property Type: [Retrieved from user profile]
- Number of properties: [Retrieved from user profile]

CUSTOMIZATION RULES:
1. ALWAYS start with: "In [STATE], for your [PROPERTY TYPE]..."
2. ALWAYS mention state-specific rules
3. ALWAYS show differences between states if relevant
4. ALWAYS reference specific laws
5. ALWAYS include practical next steps
6. ALWAYS add appropriate disclaimers

STATE-SPECIFIC RULES (You know these):
PENANG:
- Notice period: 30 days
- Late rent grace: 14 days
- Deposit return: 30 days
- Tenant protection: Very high
- Strata Act applies (if condo)

SELANGOR:
- Notice period: 14 days
- Late rent grace: Not specified
- Deposit return: 30 days
- Tenant protection: Medium
- Standard residential law

JOHOR:
- Notice period: 14 days
- Late rent grace: 14 days
- Deposit return: 30 days
- Tenant protection: Lower than Penang
- More landlord-friendly

[... other states ...]

PROPERTY TYPE RULES (You know these):
CONDO:
- Strata Management Act 2013 applies
- By-laws override agreement
- Maintenance fees mandatory
- Tenant protection: Very high
- By-laws are enforceable

OFFICE:
- Commercial law applies
- Few tenant protections
- Utilities: tenant pays
- Maintenance: tenant responsible
- Can evict faster

FACTORY:
- Industrial law applies
- Minimal tenant protection
- Strict use restrictions
- Highest deposits normal
- Easiest eviction

[... other types ...]

MULTI-PROPERTY HANDLING:
If user has multiple properties:
1. Ask "Which property is this about?" (if unclear)
2. Show answers for each property separately
3. Show comparison table (if relevant)
4. Aggregate financial answers (if asked)

ANSWER STRUCTURE (Always follow):
1. Direct answer (2-3 sentences)
2. State & type context
3. Specific law references
4. Step-by-step actions
5. Timeline expectations
6. What NOT to do (safety)
7. When to escalate to lawyer
8. Comparison to other states (if relevant)
9. Tools/templates available
10. Follow-up question

TONE:
- Professional but friendly
- Clear (no jargon)
- Empathetic
- Solution-focused
- Evidence-based
- Balanced (show both sides)`
```

### **Why This is Different:**

**Old Prompt:**
- Generic Malaysian landlord advice
- No state specificity
- No property type customization
- Same answer for everyone

**New Prompt:**
- State-specific answers
- Property-type specific
- Customized to individual
- Different answers for different situations
- Shows comparisons
- Explains WHY rules differ

---

## 🏗️ DATA STRUCTURE - WHAT INFORMATION YOU'D STORE

### **User Profile (Current - Simple)**

```javascript
{
  user_id: "landlord_123",
  email: "landlord@example.com",
  created_date: "2025-04-17"
}
```

**Problem:** No information about their properties or state

### **Enhanced User Profile (Proposed - NOT YET)**

```javascript
{
  user_id: "landlord_123",
  email: "landlord@example.com",
  created_date: "2025-04-17",
  
  // New field for state/property info
  default_state: "Penang",  // Primary state
  default_property_type: "Condo",  // Primary property type
  
  // New field for multiple properties
  properties: [
    {
      property_id: "prop_1",
      name: "Penang Condo",
      state: "Penang",
      property_type: "Condo",
      address: "123 Jalan Utama, Penang",
      rent_amount: 3000,
      tenant_name: "Ahmad",
      lease_start: "2024-01-01",
      lease_end: "2025-12-31"
    },
    {
      property_id: "prop_2",
      name: "Selangor Office",
      state: "Selangor",
      property_type: "Office",
      address: "456 Jalan Merdeka, Selangor",
      rent_amount: 5000,
      tenant_name: "XYZ Company",
      lease_start: "2024-03-01",
      lease_end: "2026-02-28"
    }
  ],
  
  // Preferences
  preferences: {
    language: "English",
    notification_email: true,
    tax_year_end: "December"
  }
}
```

**What This Enables:**
- ✅ Know user's state when they ask question
- ✅ Know user's property types
- ✅ Handle multiple properties
- ✅ Store user preferences
- ✅ Provide personalized answers

---

## 🔄 API CALL FLOW - HOW DATA MOVES

### **Current Flow (Simple)**

```
Frontend (Chat Input)
    ↓
Backend (/api/chat) receives:
{
  message: "What if tenant doesn't pay rent?",
  history: [...]
}
    ↓
Backend calls Claude API with:
{
  system: SYSTEM_PROMPT,
  messages: [...]
}
    ↓
Claude responds with answer
    ↓
Backend returns to Frontend
    ↓
Display in chat
```

**Problem:** No user context (state, property type)

### **Enhanced Flow (Proposed - NOT YET)**

```
Frontend (Chat Input)
    ↓
Frontend also knows user's state & property (from localStorage/session)
    ↓
Backend (/api/chat) receives:
{
  message: "What if tenant doesn't pay rent?",
  history: [...],
  user_id: "landlord_123",      // NEW
  property_id: "prop_1",         // NEW
  state: "Penang",               // NEW
  property_type: "Condo"         // NEW
}
    ↓
Backend calls Claude API with:
{
  system: SYSTEM_PROMPT (enhanced),
  messages: [...],
  context: {
    state: "Penang",
    property_type: "Condo",
    user_has_multiple_properties: true
  }
}
    ↓
Claude generates STATE-SPECIFIC answer
    ↓
Backend returns to Frontend
    ↓
Display: "In Penang, for your condo..."
```

**What This Does:**
- ✅ Claude knows the state
- ✅ Claude knows the property type
- ✅ Claude customizes answer
- ✅ Claude shows Penang-specific rules

---

## 💾 DATABASE STRUCTURE - WHERE DATA LIVES

### **Currently (Very Simple)**

```
Database has:
- User table (email, password, created_date)
- Chat history table (user_id, message, response, date)

That's it!
```

### **Would Need to Add (Not yet!)**

```
New tables:

PROPERTIES TABLE:
- property_id (unique)
- user_id (which user owns this)
- name (e.g., "Penang Condo")
- state (Penang, Selangor, etc.)
- property_type (Condo, Office, Factory, etc.)
- address
- rent_amount
- tenant info
- created_date

TEMPLATES TABLE:
- template_id (unique)
- template_name (e.g., "Late Rent Notice")
- state (Penang, Selangor, etc.)
- property_type (Condo, Office, etc.)
- content (the template text)
- version
- created_date

FAQS TABLE:
- faq_id (unique)
- question (e.g., "What if tenant doesn't pay?")
- answer (the answer text)
- state (which states does this apply to?)
- property_type (which types does this apply to?)
- category (Late Rent, Maintenance, Eviction, etc.)
- created_date
- updated_date

CALCULATORS TABLE:
- calculator_id (unique)
- name (e.g., "ROI Calculator")
- formula (the calculation logic)
- inputs_needed (what parameters)
- created_date

USER_PREFERENCES TABLE:
- preference_id (unique)
- user_id
- default_state
- default_property_type
- notification_settings
- language
- theme (light/dark)
```

**What This Enables:**
- ✅ Store user's multiple properties
- ✅ State-specific templates
- ✅ Property-type specific FAQs
- ✅ User preferences
- ✅ Version control for templates

---

## 🎨 FRONTEND CHANGES NEEDED

### **Current Frontend (What User Sees)**

```
┌─────────────────────────────────────────┐
│          UNBELIEVEBE HEADER              │
├─────────────────────────────────────────┤
│                                          │
│  Chat Messages Display                   │
│  (Questions and Answers)                 │
│                                          │
│                                          │
│                                          │
├─────────────────────────────────────────┤
│  [Input Box: Type your question...]     │
│  [Send Button]                           │
└─────────────────────────────────────────┘
```

**That's it! Very simple.**

### **Enhanced Frontend (Proposed - NOT YET)**

```
┌─────────────────────────────────────────┐
│        UNBELIEVEBE HEADER                │
├─────────────────────────────────────────┤
│ 📍 Penang | 🏢 Condo | [Change]          │  ← NEW: Shows selected state/type
├─────────────────────────────────────────┤
│ YOUR PROPERTIES:                          │  ← NEW: Multi-property support
│ □ Unit 1 - Penang Condo      (RM 3,000) │
│ □ Unit 2 - Selangor Office   (RM 5,000) │
│ □ Unit 3 - Johor Factory     (RM 8,000) │
├─────────────────────────────────────────┤
│ Chat Messages Display                    │
│ (Questions and Answers)                  │
│                                          │
│ "In Penang, for your condo..."  ← NOW CUSTOMIZED
│                                          │
├─────────────────────────────────────────┤
│ [Input Box: Type your question...]      │
│ [Which property?] [Send]                 │  ← NEW: Property selector
└─────────────────────────────────────────┘
```

**New Components:**

1. **State/Property Selector** (Top)
   - Shows currently selected state
   - Shows currently selected property type
   - Can change with one click

2. **Properties List** (Left sidebar or dropdown)
   - All user's properties
   - Quick select
   - Shows rent amount

3. **Property Context Badge**
   - "📍 Penang | 🏢 Condo"
   - Always visible
   - Reminds user which property they're asking about

4. **Smart Input**
   - Recognizes if user switches properties
   - Asks "Which property?" if unclear
   - Remembers last selected property

---

## 🔐 SECURITY & PRIVACY CONSIDERATIONS

### **Current (Basic)**

```
✅ HTTPS (encrypted in transit)
✅ API key hidden (not in frontend)
✅ No user data in logs
✅ Basic password security

❌ NOT covered:
- Data encryption at rest
- PDPA compliance
- Data backup & recovery
- Audit logging
```

### **Would Need to Add (Not yet!)**

```
PDPA COMPLIANCE (Malaysia):
- ✅ Explicit consent for data collection
- ✅ Clear privacy policy
- ✅ Data retention limits
- ✅ User can request data deletion
- ✅ Data breach notification process

DATA SECURITY:
- ✅ Encryption at rest (database)
- ✅ Encryption in transit (HTTPS)
- ✅ Regular backups
- ✅ Access controls
- ✅ Audit logging
- ✅ Two-factor authentication (optional)

PROFESSIONAL LIABILITY:
- ✅ Professional Indemnity Insurance
- ✅ Clear disclaimers
- ✅ Limitation of liability clause
- ✅ Terms of Service agreement
```

---

## 💰 COST IMPLICATIONS OF CHANGES

### **Current Setup (What You Have)**

```
Monthly Costs:
- Vercel hosting: RM 0 (free tier)
- Claude API: RM 5-20 (pay-as-you-go)
- Domain: RM 0 (optional)
- Email: RM 0 (can use free)

TOTAL: RM 5-20/month
```

### **Enhanced Setup (What Would Be Needed)**

```
Additional Monthly Costs:

Database:
- PostgreSQL (managed): RM 20-100
- Or Firebase: RM 20-50
(Currently using free local storage)

Professional Team:
- Part-time lawyer: RM 2,000-3,000
- Part-time accountant: RM 1,500-2,500
(Not needed for MVP, needed for Phase 1)

Backend Improvements:
- Server/hosting upgrade: RM 50-200
- Possible (free tier might be limited)

Analytics & Monitoring:
- Error tracking (Sentry): RM 0 (free tier)
- Analytics: RM 0 (free)

TOTAL ADDITIONAL: RM 2,570-5,850/month

But this is ONLY needed when scaling (Phase 1+)
```

### **When You'd Need These Changes**

```
MVP Stage (Week 1-2):      Keep current (free)
Phase 1 (Week 3-8):        Start Phase 1 changes
Phase 2+ (Week 9+):        All changes in place
```

---

## ⏱️ IMPLEMENTATION TIMELINE

### **Current MVP (DONE)**
```
Week 1-2:
- Frontend: Simple chat UI
- Backend: Route.js with system prompt
- Database: Local/simple storage
- Deployment: Vercel free tier
- No user authentication
- No multi-property support
```

### **Phase 1 Changes (If doing Phase 1)**
```
Week 3-4:
- Add state/property selector to frontend
- Update system prompt with state rules
- Hire lawyer & accountant
- Create professional terms & policies

Week 5-6:
- Build property profiles database
- Update backend to pass state/type context
- Improve UI/UX to professional standard
- Create law database

Week 7-8:
- Create 20+ templates (state-specific)
- Complete Q&A library (100+ articles)
- Professional design refresh
- Lawyer reviews everything
```

### **Phase 2+ Changes**
```
Week 9-12: Expand legal expertise
Week 13-16: Add financial modules
Week 17-20: Add strategic planning
Week 21-26: Polish & monetize
```

---

## 🧪 WHAT CHANGES WOULD BREAK?

### **If You Add Multi-State Support Without Planning**

```
❌ RISK 1: User gets wrong law
   Problem: If system prompt not updated, Claude gives generic answer
   Impact: User acts on wrong rules for their state
   
❌ RISK 2: Templates are state-wrong
   Problem: If you give Penang template to Selangor user
   Impact: Agreement might not be enforceable in Selangor
   
❌ RISK 3: Calculations wrong
   Problem: If calculator uses Penang tax rules for all states
   Impact: User pays wrong tax amount
   
❌ RISK 4: UI confusion
   Problem: If UI doesn't show which property/state selected
   Impact: User doesn't know which answer is for which property
```

### **How to Avoid These Risks**

```
✅ STEP 1: Update system prompt FIRST
   (Tell Claude about states before changing UI)

✅ STEP 2: Create state-specific templates
   (Have lawyer verify for each state)

✅ STEP 3: Update calculators
   (Have accountant verify for each state)

✅ STEP 4: Test thoroughly
   (Test with 10 scenarios per state)

✅ STEP 5: Show state context always
   (UI always shows which state/type)
```

---

## 📊 FEATURE COMPLEXITY vs VALUE

### **Simple Features (Easy to Add)**

```
LOW COMPLEXITY, HIGH VALUE:
1. State selector dropdown
   - Effort: 2 hours
   - Value: Huge (customizes answers)
   - Risk: Low

2. Property selector
   - Effort: 4 hours
   - Value: Very high (for multi-property users)
   - Risk: Low

3. System prompt update
   - Effort: 2 hours
   - Value: Huge (makes answers state-specific)
   - Risk: Low
```

### **Medium Complexity Features**

```
MEDIUM COMPLEXITY, HIGH VALUE:
1. Database for properties
   - Effort: 16 hours
   - Value: High (stores user preferences)
   - Risk: Medium

2. Template library (by state)
   - Effort: 40 hours
   - Value: Very high (solves real problem)
   - Risk: Low (if templates are correct)

3. Financial calculators
   - Effort: 32 hours
   - Value: Very high
   - Risk: Medium (must be accurate)
```

### **Complex Features (Take More Time)**

```
HIGH COMPLEXITY, MEDIUM VALUE:
1. Full portfolio management
   - Effort: 80+ hours
   - Value: High (for investors)
   - Risk: High (lots of moving parts)

2. Integration with accounting software
   - Effort: 60+ hours
   - Value: Medium (nice-to-have)
   - Risk: High (requires partners)

3. Professional services booking
   - Effort: 40+ hours
   - Value: High (generates revenue)
   - Risk: Medium (scheduling complexity)
```

---

## 🎯 DECISION FRAMEWORK: WHAT TO IMPLEMENT

### **For MVP (Week 1-2) - MINIMUM**
```
✅ Keep current setup (no changes)
✅ Just get users and feedback
✅ Very fast, very cheap
✅ Validate product-market fit
```

### **For Phase 1 (Week 3-8) - RECOMMENDED**
```
✅ Add state selector
✅ Update system prompt with state rules
✅ Create 20+ state-specific templates
✅ Update UI to show state context
✅ Professional branding & terms

NOT YET:
❌ Don't build full portfolio system
❌ Don't build property database yet
❌ Don't integrate accounting software
```

### **For Phase 2-4 (Week 9-20) - SCALE**
```
✅ Build property database
✅ Financial calculators
✅ FAQ system (by state)
✅ Professional services booking

NOT YET:
❌ Don't build marketplace
❌ Don't build mobile app
```

### **For Phase 5+ (Week 21+) - POLISH**
```
✅ Premium tier features
✅ Advanced analytics
✅ Team collaboration tools
✅ API for partners
```

---

## 📋 DETAILED CHECKLIST: BEFORE MAKING ANY CHANGES

### **Before Adding Multi-State Support**

- [ ] Test current MVP thoroughly (50+ questions)
- [ ] Collect user feedback
- [ ] Verify Claude's answer quality (score ≥4.5/5)
- [ ] Document exactly which states/types you'll support
- [ ] Get lawyer input on law differences
- [ ] Get accountant input on financial differences
- [ ] Plan UI changes (sketch them out)
- [ ] Plan database changes (schema design)
- [ ] Plan system prompt changes (write new version)
- [ ] Risk assessment (what could go wrong?)
- [ ] Testing plan (how will you verify it works?)

### **Before Hiring Professionals**

- [ ] Decide if Phase 1 is your path
- [ ] Calculate budget (RM 16k-27k)
- [ ] Identify potential lawyers (3-5 candidates)
- [ ] Identify potential accountants (3-5 candidates)
- [ ] Create job descriptions/scope of work
- [ ] Negotiate rates (RM 2,000-3,000/month for lawyer)
- [ ] Check credentials & references
- [ ] Draft contracts/agreements
- [ ] Plan onboarding process
- [ ] Define deliverables & timelines

### **Before Making Code Changes**

- [ ] Backup current code & database
- [ ] Create development branch (not changing live code)
- [ ] Test all changes locally first
- [ ] Write unit tests for changes
- [ ] Test with real data
- [ ] Document all changes
- [ ] Plan rollback if something breaks
- [ ] Have someone else review code
- [ ] Deploy to staging environment first
- [ ] Test thoroughly in staging
- [ ] Only then deploy to production

---

## ✅ THIS IS JUST UNDERSTANDING

**Remember:** We're NOT making any of these changes yet!

We're just:
1. Understanding how current system works
2. Understanding what changes would be needed
3. Understanding the implications
4. Planning, not executing

Once you understand everything, THEN you can decide:
- What to change?
- When to change it?
- How to change it?
- Who will help you change it?

**Ready to dive deeper into any specific area?**

---
