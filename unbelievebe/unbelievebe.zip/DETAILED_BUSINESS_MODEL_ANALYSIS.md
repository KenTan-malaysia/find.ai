# Detailed Business Model Analysis

## 💰 CURRENT BUSINESS MODEL (MVP STAGE)

### **Revenue Model: NONE (It's Free)**

```
What users pay: RM 0

Why:
- MVP phase
- Building user base
- Collecting feedback
- No monetization yet

Pros:
✅ Users will try without hesitation
✅ Easy user acquisition
✅ Can gather data
✅ Build credibility

Cons:
❌ No income
❌ Can't hire professionals
❌ Can't invest in features
❌ Can't scale without revenue
```

### **Cost Model: Minimal**

```
Monthly Costs (MVP Stage):

1. Hosting: RM 0
   - Using Vercel free tier
   - Scales automatically
   - No cost until viral

2. Claude API: RM 5-20
   - Pay per API call
   - Each question = 1 API call
   - With 100 users × 5 questions = RM 10-20

3. Domain: RM 0 (optional)
   - If using Vercel subdomain (free)
   - Or RM 20-30/year if custom domain

4. Email: RM 0
   - Using free Gmail

5. Other: RM 0

TOTAL: RM 5-20/month
```

**Sustainability:** 
- ✅ Can run forever on RM 20/month
- ❌ Can't grow without money
- ❌ Can't hire anyone
- ✅ Perfect for validating idea

---

## 💵 PHASE 1 BUSINESS MODEL (Professional Foundation)

### **Revenue Model: Still Free (But Preparing for Monetization)**

```
Why still free in Phase 1?
- Building professional credibility
- Creating comprehensive content
- Getting lawyer/accountant oversight
- Establishing trust
- Planning monetization strategy

When to monetize?
After Phase 1 → Phase 2 launch

Goal of Phase 1:
- Have 100-200 users
- Get positive feedback
- Ready to charge users who want premium
```

### **Cost Model: MUCH Higher (But Strategic Investment)**

```
Monthly Costs (Phase 1):

1. Hosting & Infrastructure: RM 50-100
   - Upgraded Vercel
   - PostgreSQL database
   - Backups
   - Monitoring

2. Claude API: RM 20-50
   - More usage
   - More sophisticated calls
   - More users

3. Professional Team: RM 3,500-5,500
   - Lawyer (part-time): RM 2,000-3,000
   - Accountant (part-time): RM 1,500-2,500
   (This is THE big cost)

4. Tools & Software: RM 200-500
   - Project management
   - Design tools
   - Analytics
   - Error tracking

5. Marketing & Content: RM 500-1,000
   - Social media
   - Content creation
   - Blog posts
   - Webinars

6. Domain & Email: RM 50-100
   - Professional domain
   - Professional email
   - SSL certificate

7. Other: RM 200-300
   - Miscellaneous
   - Contingency

TOTAL: RM 4,520-7,550/month

Over 6 months (Phase 1): RM 27,120-45,300
```

**Sustainability:**
- ❌ Can't sustain this without revenue
- ✅ Can run for 6 months with RM 27k-45k investment
- ❌ After 6 months, need revenue

**Where does RM 27k-45k come from?**
- Your savings?
- Business loan?
- Investment/investor?
- Profit from other business?

---

## 💸 PHASE 2 BUSINESS MODEL (Start Monetization)

### **Revenue Model: Freemium + Premium**

When Phase 2 launches (Week 9-12):
- Have 300-500 users
- Have comprehensive content
- Have professional credibility
- Ready to charge

#### **FREE TIER**
```
Who uses:
- 95% of users (want to try before paying)
- Price-sensitive
- Just asking questions

What they get:
- Q&A chatbot
- Basic FAQ
- Basic templates (5-10)
- Community forum
- Read-only access to guides

How many: 285 users (95% of 300)

Revenue: RM 0
```

#### **PREMIUM TIER** (NEW in Phase 2)

```
Price: RM 9.99/month (or RM 99/year)

Who uses:
- 3-5% of free users want more
- Have multiple properties
- Want priority support

What they get:
- Everything in Free +
- Priority email support (24-hour response)
- Document generator (word/pdf)
- Expense tracker
- Advanced calculators (ROI, yield)
- No ads
- Early access to new features
- Monthly email digest

Who converts:
- User with 2+ properties
- User who asks >5 questions
- User who wants to save templates
- User who wants to track finances

Conversion rate: 3-5% (typical for freemium)
Number of premium users at launch: 3-5 (from 100 free)
Growing to: 15-25 by end of Phase 2 (from 500 free)

Revenue:
- Month 1: 3 users × RM 9.99 = RM 30
- Month 2: 5 users × RM 9.99 = RM 50
- Month 3: 10 users × RM 9.99 = RM 100
- Month 4: 15 users × RM 9.99 = RM 150

Average for Phase 2 (4 months): RM 80/month

Phase 2 Total Revenue: RM 320
```

**Observation:** 
- Phase 2 revenue (RM 320) << Phase 2 costs (RM 18,080)
- Revenue barely covers 1% of costs
- Monetization takes time to build!

---

## 💎 PHASE 3 BUSINESS MODEL (Financial Focus)

### **Revenue Model: Free + Premium + Professional**

When Phase 3 launches (Week 13-16):
- Have 800-1,200 users
- Have professional financial content
- Ready for "Professional Tier"

#### **FREE TIER (Unchanged)**
```
95% of users
Revenue: RM 0
```

#### **PREMIUM TIER (Growing)**
```
Price: RM 9.99/month

Now includes:
- Everything phase 2 +
- Expense tracker with tax reports
- Financial calculators (9+)
- Monthly financial summary
- ROI analysis dashboard

Conversion rate: 3-5%
Premium users by Phase 3 launch: 25
Growing to: 50 by end of Phase 3

Revenue:
Month 1: 25 × RM 9.99 = RM 250
Month 2: 30 × RM 9.99 = RM 300
Month 3: 40 × RM 9.99 = RM 400
Month 4: 50 × RM 9.99 = RM 500

Average: RM 363/month
Phase 3 Total Revenue: RM 1,452
```

#### **PROFESSIONAL TIER** (NEW in Phase 3)

```
Price: RM 99-199/month (let's say RM 150 average)

Who uses:
- 1-2% of users with valuable time
- Multiple properties (2+)
- Want professional guidance
- Can afford RM 150/month

What they get:
- Everything in Premium +
- Monthly lawyer consultation (1 hour)
- Quarterly accountant consultation
- Portfolio analysis (quarterly)
- Strategic planning session (quarterly)
- Dedicated account manager
- Custom reports

Who converts:
- User with 3+ properties
- User with high rent income (RM 10,000+/month)
- User doing professional investing
- User wanting to scale

Conversion rate: 1-2% (much lower, higher price)
Professional users at Phase 3 launch: 1-2
Growing to: 8-12 by end of Phase 3

Revenue:
Month 1: 2 × RM 150 = RM 300
Month 2: 3 × RM 150 = RM 450
Month 3: 5 × RM 150 = RM 750
Month 4: 8 × RM 150 = RM 1,200

Average: RM 675/month
Phase 3 Total Revenue: RM 2,700
```

**Phase 3 Total Revenue:**
- Premium: RM 1,452
- Professional: RM 2,700
- **Total: RM 4,152 for 4 months**

**Observation:**
- Still not paying for RM 18,080 monthly costs
- But growing! (3x more revenue than Phase 2)
- Still need to cut costs or get investment

---

## 🎯 PHASE 4 BUSINESS MODEL (Strategic Growth)

### **Revenue Model: Free + Premium + Professional + Services**

When Phase 4 launches (Week 17-20):
- Have 1,500-2,000 users
- Have strategic content
- Ready for "Services"

#### **FREE TIER**
```
95% of users
Revenue: RM 0
```

#### **PREMIUM TIER (Growing)**
```
Premium users: 50-75
Revenue: 60 × RM 9.99 = RM 600/month
Phase 4 Total: RM 2,400
```

#### **PROFESSIONAL TIER (Growing)**
```
Professional users: 15-20
Revenue: 18 × RM 150 = RM 2,700/month
Phase 4 Total: RM 10,800
```

#### **PROFESSIONAL SERVICES** (NEW in Phase 4)

```
What's offered:
1. Lawyer Document Review
   - Review tenant agreement
   - Check for compliance
   - Identify risks
   Price: RM 500-1,000
   Frequency: ~2 per month
   Revenue: RM 1,000-2,000

2. Accountant Consultation
   - Tax planning session
   - Expense optimization
   - Multi-property strategy
   Price: RM 300-500
   Frequency: ~5 per month
   Revenue: RM 1,500-2,500

3. Strategic Planning Session
   - Portfolio analysis
   - Investment strategy
   - Risk assessment
   Price: RM 500-1,000
   Frequency: ~3 per month
   Revenue: RM 1,500-3,000

Total Services Revenue:
RM 4,000-7,500/month
Phase 4 Total: RM 16,000-30,000
```

**Phase 4 Total Revenue:**
- Premium: RM 2,400
- Professional: RM 10,800
- Services: RM 16,000-30,000
- **Total: RM 29,200-43,200 for 4 months**
- **Monthly average: RM 7,300-10,800**

**Observation:**
- Finally approaching RM 18,080 monthly costs!
- Services are the big revenue driver
- With 2,000 users, can generate real revenue

---

## 📊 PHASE 5 BUSINESS MODEL (Profitability)

### **Revenue Model: Full Monetization**

When Phase 5 completes (Week 21-26):
- Have 2,500+ users
- Have professional services running
- Have launched premium tiers
- Ready for sustained revenue

#### **Current Users by Phase 5:**

```
Total Users: 2,500

Breakdown:
- Free users: 2,400 (96%)
- Premium users: 80 (3%)
- Professional users: 20 (1%)
```

#### **Revenue Streams:**

```
1. PREMIUM TIER (RM 9.99/month)
   Users: 80
   Revenue: 80 × RM 9.99 = RM 800/month
   Annual: RM 9,600

2. PROFESSIONAL TIER (RM 150/month)
   Users: 20
   Revenue: 20 × RM 150 = RM 3,000/month
   Annual: RM 36,000

3. PROFESSIONAL SERVICES
   Lawyer reviews: 3/month × RM 750 avg = RM 2,250
   Accountant: 8/month × RM 400 avg = RM 3,200
   Strategic: 5/month × RM 750 avg = RM 3,750
   Total: RM 9,200/month
   Annual: RM 110,400

4. PARTNERSHIPS & REFERRALS
   Lawyer referral commissions: RM 500/month
   Accountant referrals: RM 300/month
   Property manager referrals: RM 200/month
   Insurance: RM 500/month
   Total: RM 1,500/month
   Annual: RM 18,000

TOTAL MONTHLY REVENUE: RM 14,500
TOTAL ANNUAL REVENUE: RM 174,000
```

#### **Cost Structure by Phase 5:**

```
Monthly Costs:

1. Team (Reduced):
   - Senior lawyer (0.5 FTE): RM 2,000
   - Accountant (0.5 FTE): RM 1,500
   - Developer/operator (1 FTE): RM 3,000
   Subtotal: RM 6,500

2. Infrastructure: RM 500
3. Tools & Software: RM 500
4. Marketing: RM 1,000
5. Other: RM 500

TOTAL MONTHLY COSTS: RM 9,000
```

#### **Profitability:**

```
Monthly Revenue: RM 14,500
Monthly Costs: RM 9,000
Monthly Profit: RM 5,500

Annual Revenue: RM 174,000
Annual Costs: RM 108,000
Annual Profit: RM 66,000

Profit Margin: 38%

ROI on RM 27k-45k Phase 1 investment:
- Payback period: 5-8 months
- Annual ROI: 150-245%
```

---

## 📈 REVENUE GROWTH TRAJECTORY

### **Quarter by Quarter**

```
PHASE 0 (MVP):       Revenue: RM 0      (free)
PHASE 1 (Months 1-2):
  Month 1: RM 0 (free)
  Month 2: RM 0 (free)

PHASE 2 (Months 3-4): Revenue: RM 80/month average
  Month 3: RM 30 (Premium 3 users)
  Month 4: RM 50 (Premium 5 users)

PHASE 3 (Months 5-6): Revenue: RM 363/month average
  Month 5: RM 250 (Prem 25, Prof 0)
  Month 6: RM 500 (Prem 50, Prof 8)

PHASE 4 (Months 7-8): Revenue: RM 9,100/month average
  Month 7: RM 7,300 (Prem 50, Prof 15, Services RM 4k)
  Month 8: RM 10,800 (Prem 75, Prof 20, Services RM 7.5k)

PHASE 5 (Months 9-12): Revenue: RM 14,500/month average
  Month 9: RM 12,000
  Month 10: RM 14,500
  Month 11: RM 14,500
  Month 12: RM 14,500 (SUSTAINABLE!)

TOTAL REVENUE (12 months):
RM 0 + RM 0 + RM 160 + RM 1,452 + RM 18,200 + RM 58,000
= RM 77,812 total
= RM 6,484 average per month
```

---

## 💳 PAYMENT MECHANICS (How Users Pay)

### **Current (No Payments)**
```
No payment system needed
Users: Free
Revenue: RM 0
```

### **Phase 2+ (Need Payment System)**

```
PAYMENT GATEWAY:
- Stripe (international, RM 2.8% + RM 0.30)
- Or 2Checkout (Malaysia-friendly, RM 3.5%)
- Or PayPal (RM 3.6%)

SUBSCRIPTION BILLING:
- Recurring monthly charge
- Auto-renewal (cancel anytime)
- Invoice via email
- Receipt & proof of payment

INVOICE EXAMPLE (Premium Tier):

Date: April 17, 2025
Invoice: INV-2025-001234

Unbelievebe Premium Subscription
Description: Monthly subscription (April 2025)
Amount: RM 9.99
Payment method: Credit card ****1234
Status: Paid
Next billing: May 17, 2025

Download PDF | Print
```

### **Payment Structure:**

```
What Stripe Takes:
User pays: RM 9.99
Stripe fee: RM 0.50 (5%)
You receive: RM 9.49

For RM 150 Professional:
You receive: RM 145.50 (after 3.5% fee)

For RM 1,000 Services:
You receive: RM 965 (after 3.5% fee)
```

---

## 📊 UNIT ECONOMICS (Per User Value)

### **Free User**
```
Acquisition cost: RM 0 (organic)
Lifetime value: RM 0
Profit: RM 0

But: These convert to paid (eventually)
Value: Credibility, network effects
```

### **Premium User**
```
Acquisition: Free → Premium (conversion)
Monthly revenue: RM 9.99
Expected lifetime: 12 months (conservative)
Lifetime value: RM 120

Actual costs (per user): RM 5 (hosting, API, support)
Profit per user: RM 115

Ideal monthly users: 100
Monthly revenue: RM 1,000
```

### **Professional User**
```
Acquisition: Premium → Professional (upgrade)
Monthly revenue: RM 150
Expected lifetime: 24 months (more valuable)
Lifetime value: RM 3,600

Actual costs (per user): RM 20 (hosting, API, support, consultation)
Profit per user: RM 3,580

Ideal monthly users: 30
Monthly revenue: RM 4,500
```

### **Services User**
```
Acquisition: Professional user → Services
Average service price: RM 750
Expected frequency: 4-5 per year
Expected lifetime: 3 years
Lifetime value: RM 9,000-11,250

Actual costs: RM 500 (lawyer/accountant cut)
Profit per transaction: RM 250

Ideal monthly services: 10
Monthly revenue: RM 7,500
```

---

## 🎯 FINANCIAL MILESTONES

### **Break-Even Analysis**

```
FIXED COSTS (Monthly):
- Lawyer: RM 2,000
- Accountant: RM 1,500
- Developer: RM 3,000 (yourself/hire)
- Infrastructure: RM 500
- Tools: RM 500
- Marketing: RM 1,000
TOTAL: RM 8,500/month

BREAK-EVEN POINT:
Need: RM 8,500/month revenue
Options:
- 850 Premium users (RM 9.99 each)
- 57 Professional users (RM 150 each)
- 12 Services per month (RM 750 avg)
- OR combination

When achieved:
- By Phase 4 (Months 7-8), if execution is good
- By Phase 5, definitely

Observation:
- Phase 1-2: Losing money (RM 4,500-8,500/month)
- Phase 3: Getting close (RM 500-2,000 loss)
- Phase 4: Could break even mid-quarter
- Phase 5+: Profitable RM 5,500/month
```

### **Investment Return**

```
INITIAL INVESTMENT (Phase 1): RM 27,120-45,300

REVENUE GENERATED (Months 3-12): RM 77,812

NET RETURN: RM 32,512-50,692

ROI: 120-187% in first year

Better ROI metrics:
- Phase 1 investment: RM 37,200 (6 months)
- Total costs through Phase 5: RM 68,000
- Revenue generated (12 months): RM 77,812
- NET: RM 9,812
- ROI: 14% (but growing!)

Year 2 projection:
- Revenue: RM 200,000+ (growing user base)
- Costs: RM 120,000 (more efficient)
- Profit: RM 80,000+
- Much better!
```

---

## 🤔 FINANCIAL RISKS & MITIGATION

### **Risk 1: Low Conversion Rate**

```
Assumption: 3-5% of free users convert to premium

Risk: Could be only 1-2%

Impact: Revenue drops 50-75%

Mitigation:
- Test different pricing (RM 4.99 vs RM 9.99)
- Test different features (what do users want?)
- Improve onboarding
- Add testimonials & social proof
- Make premium more valuable
```

### **Risk 2: High Professional Team Costs**

```
Assumption: Lawyer RM 2,000, Accountant RM 1,500

Risk: Might need more (RM 3,000+)

Impact: Monthly costs rise RM 500-1,000

Mitigation:
- Hire more junior talent (lower cost)
- Hire independent contractors (no benefits)
- Negotiate lower rates (offer longer contracts)
- Offshore possibility (but quality risk)
```

### **Risk 3: Users Don't Trust Paid Tier**

```
Risk: Users prefer free forever

Impact: Professional tier adoption very low

Mitigation:
- Make free version very limited
- Premium tier must provide clear value
- Add features to premium (not just less ads)
- Get testimonials from paid users
- Offer 7-day free trial of premium
```

### **Risk 4: Services Don't Scale**

```
Assumption: Can do 10-12 services/month

Risk: Limited by available lawyers/accountants

Impact: Revenue cap at RM 8,000-10,000/month

Mitigation:
- Build network of 5-10 partner lawyers
- Build network of 5-10 partner accountants
- They handle overflow
- Revenue share (70/30 split)
```

---

## 💰 FUNDING OPTIONS

### **Option 1: Self-Funded (Use Savings)**

```
Required: RM 30,000-50,000 in savings
Timeline: 6 months until revenue
Risk: High (personal financial risk)
Control: Complete
Equity: None given away

Best for: If you have capital available
```

### **Option 2: Small Business Loan**

```
Amount: RM 30,000-50,000
Source: Bank, LOANSTREET, MTUAN
Rate: 8-12% per annum
Term: 3-5 years
Monthly payment: RM 600-900

Pro: Don't use personal savings
Con: Must make loan payments even if business struggles
```

### **Option 3: Angel Investment**

```
Amount: RM 50,000-100,000
Source: Angel investor (typically wealthy individual)
Equity: 10-25%
Involvement: Investor may want input

Pro: Capital + mentorship
Con: Give up ownership
Timeline: 3-6 months to find investor
```

### **Option 4: Venture Capital**

```
Amount: RM 500,000+
Source: VC fund
Equity: 15-30%
Expected: 10x return in 10 years

Pro: Large capital, professional network
Con: Significant dilution, high pressure to grow
Timeline: 6-12 months
Requirement: Impressive team, market traction
```

### **Option 5: Bootstrapped (No External Funding)**

```
How: Start with MVP, reinvest profits
Timeline: Longer (12-18 months to profitability)
Equity: 100% retained
Risk: Slower growth

Possible path:
- Month 0: MVP (free)
- Month 3: Launch Premium
- Month 6: Get first RM 500/month revenue
- Month 9: Revenue covers basic costs
- Month 12: Can hire help
- Month 18: Full Phase 4 build
```

---

## 🎯 REVENUE ASSUMPTIONS (What We're Betting On)

### **Conversion Assumptions**

```
Assumption 1: 3-5% of free users convert to premium
Basis: Industry standard SaaS conversion
Reality check: Could be 1-10% depending on product
```

### **Pricing Assumptions**

```
Assumption 2: Premium users will pay RM 9.99/month
Basis: Similar products in market
Reality check: Could be RM 5-20 depending on value

Assumption 3: Professional users will pay RM 99-199/month
Basis: Professional services pricing
Reality check: Could be RM 50-300 depending on value
```

### **User Growth Assumptions**

```
Assumption 4: Can acquire 500 users by Phase 3
Basis: No paid marketing, organic growth
Reality check: Could be 100-2,000 depending on product quality

Assumption 5: Will retain 80% of users monthly
Basis: Product is useful, sticky
Reality check: Could be 50-95% depending on execution
```

### **Services Assumptions**

```
Assumption 6: 5-10 professional services per month
Basis: User base size and demand
Reality check: Could be 0-20 depending on availability

Assumption 7: Average service price RM 750
Basis: Market rates for professional services
Reality check: Could be RM 300-1,500 depending on service
```

### **Cost Assumptions**

```
Assumption 8: Can hire lawyer part-time for RM 2,000/month
Basis: Market rates for part-time consultants
Reality check: Could be RM 1,000-4,000 depending on location

Assumption 9: Infrastructure costs RM 500/month
Basis: Database, hosting, monitoring costs
Reality check: Could be RM 100-1,000 depending on scale
```

---

## ❓ CRITICAL QUESTIONS ABOUT BUSINESS MODEL

### **Before Committing to This Plan, Ask:**

1. **Do I have RM 30k-50k to invest?**
   - If not: Need to bootstrap or get funding
   - If yes: Can self-fund Phase 1

2. **Am I willing to go 6 months without revenue?**
   - If not: Might not be the right path
   - If yes: Can do it

3. **Do I believe users will pay RM 10+/month?**
   - If not: Model breaks down
   - If yes: Pursue this

4. **Do I believe I can get professional team help?**
   - If not: Can't build credibility
   - If yes: Can proceed

5. **Am I committed to 12+ months?**
   - If not: Might not reach profitability
   - If yes: Have patience for growth

6. **Do I have another income source?**
   - If not: Need to fund from savings
   - If yes: Can fund Phase 1 more easily

---

## ✅ FINANCIAL SUMMARY

```
MVP Stage:     RM 5-20/month (sustainable)
Phase 1:       RM 4,520-7,550/month costs, RM 0 revenue
Phase 2-3:     RM 18,080/month costs, RM 364/month revenue
Phase 4:       RM 18,080/month costs, RM 9,100/month revenue
Phase 5:       RM 9,000/month costs, RM 14,500/month revenue

The picture:
- MVP: Basically free, no cost
- Phase 1: Costs money, but strategic investment
- Phase 2-3: Still losing money, but building
- Phase 4: Getting close to break-even
- Phase 5: Profitable and sustainable!

The investment:
- Total Phase 1-5: RM 68,000 over 6 months
- But generates RM 77,812 revenue in year 1
- Net: Small profit, but more importantly:
  - Built credible business
  - Have 2,500+ users
  - Have RM 14,500/month recurring revenue
  - Platform worth RM 1-5 million

The ROI:
- Year 1: Break-even to small profit
- Year 2+: RM 80,000-200,000+ annual profit
- Scalability: Can grow to RM 100,000+/month
- Exit potential: Sell for 5-10x revenue = RM 5-20 million
```

---

This is a detailed financial picture.

The key insight: **Phase 1 is an investment, not an expense.**

You spend RM 27k-45k in Phase 1 to build credible platform that generates RM 14.5k/month recurring revenue by Phase 5.

That's a 3-5x return in the first year, and much better in years 2+.

---

Ready to understand other business aspects in detail?
